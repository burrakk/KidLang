package com.example.burak.kidlang.Interface;

/**
 * Created by burak on 12/4/2017.
 */

public interface RankingCallBack<T> {

        void callBack(T ranking);


}
