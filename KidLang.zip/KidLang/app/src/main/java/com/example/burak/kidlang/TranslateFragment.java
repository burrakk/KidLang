package com.example.burak.kidlang;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;


public class TranslateFragment extends Fragment {

    EditText mInputText;
    TextView mOutputText;
    Button translateEnTr,translateTrEn;
    String entrString="en-tr";
    String trenString="tr-en";
    String sText;
    String yandexKey ="trnsl.1.1.20171204T180628Z.8e82d8e6b7a7ed17.f7835bc71c71adabdd01ec0ffa42e34270a02c8e";


    View myFragment;

    public static TranslateFragment newInstance(){
        TranslateFragment translateFragment = new TranslateFragment();
        return translateFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        myFragment = inflater.inflate(R.layout.fragment_translate,container,false);
        return myFragment;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mInputText = (EditText) view.findViewById(R.id.inputText);
        mOutputText = (TextView)view.findViewById(R.id.OutputText);
        translateEnTr = (Button)view.findViewById(R.id.TranslateButtonEnTr);
        translateTrEn = (Button)view.findViewById(R.id.TranslateButtonTrEn);

        translateEnTr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sText=mInputText.getText().toString();
                String query = null;
                try{
                    query = URLEncoder.encode(sText,"utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                String urlString = "https://translate.yandex.net/api/v1.5/tr.json/translate?key="+yandexKey+"&text="+query+"&lang="+entrString;
                new TranslatorBackgroundTask().execute(urlString);
            }
        });

        translateTrEn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sText=mInputText.getText().toString();
                String query = null;
                try{
                    query = URLEncoder.encode(sText,"utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                String urlString = "https://translate.yandex.net/api/v1.5/tr.json/translate?key="+yandexKey+"&text="+query+"&lang="+trenString;
                new TranslatorBackgroundTask().execute(urlString);
            }
        });



    }

    class TranslatorBackgroundTask extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... params){
            String urlString=params[0];
            StringBuilder jsonString = new StringBuilder();
            try{

                URL yandexUrl=new URL(urlString);
                HttpURLConnection httpURLConnection = (HttpURLConnection) yandexUrl.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line ;
                while ((line=bufferedReader.readLine())!=null){
                    jsonString.append(line);
                }
                inputStream.close();
                bufferedReader.close();
                httpURLConnection.disconnect();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return jsonString.toString();
        }
        @Override
        protected void onPostExecute(String json){
            JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
            String translate = jsonObject.get("text").getAsString();
            mOutputText.setText(translate);

        }

    }
}
