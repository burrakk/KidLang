package com.example.burak.kidlang.Common;

import com.example.burak.kidlang.Model.Question;
import com.example.burak.kidlang.Model.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by burak on 12/4/2017.
 */

public class Common {

    public static String categoryId,categoryName;
    public static User CurrentUser;
    public static List<Question> questionList = new ArrayList<>();
}
