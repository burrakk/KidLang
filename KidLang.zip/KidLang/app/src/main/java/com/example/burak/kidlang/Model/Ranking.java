package com.example.burak.kidlang.Model;

/**
 * Created by burak on 12/4/2017.
 */

public class Ranking {
    private String userName;
    private long score;


    public Ranking(String userName, long score) {
        this.userName = userName;
        this.score = score;
    }

    public Ranking() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getScore() {
        return score;
    }

    public void setScore(long score) {
        this.score = score;
    }
}
