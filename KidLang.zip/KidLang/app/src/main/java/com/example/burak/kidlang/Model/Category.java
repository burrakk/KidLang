package com.example.burak.kidlang.Model;

/**
 * Created by burak on 12/2/2017.
 */

public class Category {
    private String Name;
    private String imageurl;


    public Category(){


    }
    public Category(String name, String image) {
        Name = name;
        imageurl = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getimageurl() {
        return imageurl;
    }

    public void setimageurl(String image) {
        this.imageurl = image;
    }


}
