package com.example.burak.kidlang.Interface;

import android.view.View;

/**
 * Created by burak on 12/2/2017.
 */

public interface ItemClickListener {
    void onClick(View view,int positon,boolean isLongClick);
}
